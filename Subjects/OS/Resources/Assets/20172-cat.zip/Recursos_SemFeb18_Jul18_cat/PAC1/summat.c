#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define N 64

// Matrices: 
int R[N][N], A[N][N], B[N][N];

int main()
{
	int x,y,z;
	char str[100];

	// Matrices initialization.
	for(x=0;x<N;x++)
	{
		for(y=0;y<N;y++) 
		{
			A[x][y] = x;
			B[x][y] = y;
		}
	}

	// Add matrices.
	for(x=0;x<N;x++)
	{
		for(y=0;y<N;y++) 
		{
			R[x][y] = A[x][y] + B[x][y];	
		}
	}	

	// Print result matrix
	for(x=0;x<N;x++)
	{
		for(y=0;y<N;y++) 
		{
			sprintf(str,"%d ",R[x][y]);
			if (write(1,str,strlen(str))<0)
				perror("Write result matrix.");
		}
			if (write(1,"\n",strlen("\n"))<0)
				perror("Write result matrix.");		
	}
	
	exit(0);
}
