#!/bin/bash

# Shellscript que mostra el funcionament de la sentencia while
#
# Aquest shellscript comprova periodicament el nombre de processos que hi
# ha en execucio a la maquina. Si aquest nombre supera un cert limit,
# escriu un missatge indicant-ho

# Variables del shellscript
temps=5		# Cada quants segons fem la comprovacio
limit=40	# Limit de processos

echo Configuracio: comprovar cada $temps segons, limit de $limit processos

while sleep $temps
do
	procs=`ps h -ef | wc -l`		# Calcula nombre de processos
	echo `date` : Processos = $procs
	if test $procs -gt $limit		# Compara si supera el limit
	then
		echo -e "\t\tLimit de processos superat"
	fi
done

