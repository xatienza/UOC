#!/bin/bash

# Shellscript que mostra l'us de la sentencia for
#
# Aquest shellscript mostra el nombre de processos que te en execucio cada usuari del sistema
#
# Un efecte similar el podem obtenir executant la seguent linia de comandes:
# ps h -ef | cut -c1-8 | sort | uniq -c

echo -e "USER      PROCS"		# Mostrem nom de les columnes
usuaris=`cut -d: -f1 /etc/passwd` 	# Obtenim llista d'usuaris del sistema	
for usuari in $usuaris			# Iterem sobre cada usuari
do
	procs=`ps h -u $usuari | wc -l`	# Obtenim nombre de processos que te en execucio l'usuari
	if test $procs -gt 0 
	then
		echo -e "$usuari\t$procs"	# Mostre usuari i nombre de processos
	fi
done
