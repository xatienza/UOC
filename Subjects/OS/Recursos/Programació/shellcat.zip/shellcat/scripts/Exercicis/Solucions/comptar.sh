#!/bin/bash

rm B 2>/dev/null		# Esborrem el fitxer B

num_linia=0			# Comptador nombre de linies

tr \' \  <A | while read linia # Substituim els apostrofs per blancs (comanda tr) i iterem sobre les linies del fitxer resultant
do
	num_linia=`expr $num_linia + 1`	# Actualizem comptador de linies
	compt=(0 0 0 0 0 0)		# Inicialitzem vector de comptadors (la posicio 0 contindra el nombre de paraules amb mes de 5 lletres, la posicio 1 el nombre de paraules amb una lletra, la posicio 2 el nombre de paraules amb dues lletres, ...

	for paraula in $linia		# Iterem sobre les paraules de linia
	do
		mida=`echo -n $paraula | wc -c`		# Calculem mida de la paraula (posem el -n per no comptar el salt de linia)
		if test $mida -gt 5			# Si es mes gran que 5, canviem el valor per un 0
		then
			mida=0
		fi
		compt[$mida]=`expr ${compt[$mida]} + 1`	# Actualizem posicio del vector
	done

	# Imprimim comptadors
	echo "$num_linia   c1:${compt[1]}  c2:${compt[2]}  c3:${compt[3]}  c4:${compt[4]}  c5:${compt[5]}  c>5:${compt[0]}" 
done  >> B
