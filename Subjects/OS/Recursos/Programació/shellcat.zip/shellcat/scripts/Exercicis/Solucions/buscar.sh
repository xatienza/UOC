#!/bin/bash

# Comprovem que el nombre d'arguments es correcte
if test $# -lt 2
then
	echo Falten arguments
	echo Us: $0 fitxer paraula [...]
	exit
fi

# Verifiquem que el fitxer existeix
if test ! -f $1
then
	echo $1 no existeix o no es un fitxer ordinari
	exit
fi

fitxer=$1	# Guardem el nom de fitxer a una variable

shift		 # Ens desfem del nom de fitxer a la llista de parametres per poder iterar sobre les paraules a buscar

for paraula_a_buscar in $*				# Iterem sobre les paraules a buscar
do
	# Substituim els blancs i els apostrofs per salts de linia, busquem la paraula exacta (parametre -w) i comptem el nombre de linies retornat
	echo `tr "' "  "\n\n" < $fitxer | grep -w $paraula_a_buscar | wc -l` $paraula_a_buscar
done
