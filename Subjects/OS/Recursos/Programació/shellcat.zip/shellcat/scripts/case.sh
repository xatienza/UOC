#!/bin/bash

# Shellscript que mostra l'us de la sentencia case
#
# Ens diu el nom en catala del dia de la setmana corresponent a avui

dia=`date | cut -c0-3`
case $dia in
	Mon|lun) dia=Dilluns ;;
	Tue|mar) dia=Dimarts ;;
	Wed|mie) dia=Dimecres ;;
	Thu|jue) dia=Dijous ;;
	Fri|vie) dia=Divendres ;;
	Sat|sab) dia=Dissabte ;;
	Sun|dom) dia=Diumenge ;;
	*)   echo Error. $dia no es cap dia conegut; exit ;;
esac

echo Avui es $dia

