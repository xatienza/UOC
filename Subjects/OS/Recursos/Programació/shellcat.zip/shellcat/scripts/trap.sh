#!/bin/bash

# Shellscript que mostra l'us de la sentencia trap
#
# Defineix les rutines d'atencio als signls 2, 14 i 15
# Executa un bucle infinit esperant l'arribada d'aquests signals

# Definicions de rutines d'atencio als senyals
trap 'echo Senyal rebuda 2 ; exit' 2  # Escriu misstage i acaba
trap 'echo Senyal rebuda 14' 14       # Escriu missatge
trap 'echo Senyal rebuda 15' 15       # Escriu missatge

echo Programa preparat per tractar signals
echo Executa des d\'una altra finestra alguna de les seguents comandes
echo -e "\tkill -2 $$"			# La variable $ ens dona el pid del proces que executa el shellscript
echo -e "\tkill -14 $$"
echo -e "\tkill -15 $$"
echo O prem Ctrl-C des d\'aquesta finestra

# Bucle infinit
while (true)
do
	sleep 1
done
