#!/bin/bash

# Shellscript que mostra un exemple de com manipular els parametres d'un shellscript
#
# El shellscript mostra informacio sobre els fitxers especificats
# Per defecte, ens mostra qui es el propietari de cada fitxer especificat
# Amb el flag -p, tambe ens mostra els permisos de cada fitxer
# Amb el flag -m, tambe ens mostra la mida de cada fitxer

# Comprovacio de nombre de caracters (variable #)
if test $# -lt 1
then
	echo Nombre de parametres incorrecte
	echo Us: $0 [-p] [-m] file1 [...]
	exit
fi

# Variables del shellscript
permisos=0	# Indica si cal mostrar els permisos del fitxer
mida=0		# Indica si cal mostrar la mida del fitxer

# Mostrar tots els caracters de cop (variable *)
echo Llista de tots els parametres: $*

# Mostrar els caracters un a un, iterant sobre la variable *
echo
echo Llistat del parametres un a un
i=1
for par in $*
do
	echo Parametre nombre $i: $par
	i=`expr $i + 1`
done

# Eliminem de la variable * els flags
while true
do
	case $1 in
		-p) permisos=1; shift ;;
		-m) mida=1; shift ;;
		*) break;;
	esac
done


# Mostrar tots els parametres de cop (variable *)
echo
echo Llista de tots els parametres despres d\'eliminar els flags: $*

# Bucle que mostra les dades dels fitxers
echo
echo Informacio sobre els fitxers
for file in $*
do
	echo -n fitxer = $file
	if test -e $file
	then
		if test -d $file
		then
			echo \ Es un directori
		else
			if test $permisos -eq 1
			then
				echo -n  \ permisos=`ls -l $file | cut -c2-9` 
			fi
			if test $mida -eq 1
			then
				echo -n \ mida=`ls -l $file | cut -c33-42`
			fi
			echo \ propietari=`ls -l $file | cut -c17-25` 
		fi
	else
		echo \ NO EXISTEIX
	fi
done

