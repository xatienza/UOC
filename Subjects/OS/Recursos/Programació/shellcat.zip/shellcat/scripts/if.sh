#!/bin/bash

# Shellscript que mostra el funcionament de la setencia if
#
# Es mostra un exemple on es genera la condicio d'un if amb la comanda test,
# un altre on es fa servir la comanda grep (tant sola com dintre d'una pipe)

dia=`date | cut -c9,10`
if test $dia -gt 15
then
	echo Estem a la segona quinzena del mes
else
	echo Estem a la primera quinzena del mes
fi

echo
echo -n "Introdueix un possible username i et dir� si existeix: "
read usuari
if echo $usuari | grep :
then
	echo El caracter : no pot ser present a un username
else
	if grep "^$usuari:" /etc/passwd >/dev/null  # Redireccionem a /dev/null 
                                     # per evitar que les linies coincidents 
                                     # apareguin per pantalla
	then
		echo $usuari existeix al fitxer de passwords
	else
		echo $usuari no existeix al fitxer de passwords
	fi
fi
