#!/bin/bash

# Shellscript que mostra l'us de la sentencia until
#
# Itera fins que l'usuari prem s,S,n o N

until false
do
	echo -n "Vols continuar (s/n) ? "
	read lectura				# Guardem resposta de l'usuari a lectura
	case $lectura in
		s|S) lectura=s; break ;;	# Si ha escrit s o S, sortim del bucle
		n|N) lectura=n; break ;;	# Si ha escrit n o N, sortim del bucle
	esac
done

