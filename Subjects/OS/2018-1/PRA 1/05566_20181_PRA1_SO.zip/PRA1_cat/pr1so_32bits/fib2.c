#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>

long int fibonacci(long int n);
void store(long int n, long int res);
unsigned numDigits(long int n);
void freeMemory();

int N=0;		      // Number of fibonacci elements calculated
char **fib=NULL;  // Vector for the N fibonacci strings

int main (int argc, char *argv[])
{
	long int n;
	char str[50];

	while(read(0,&str,50)>0)
	{
		if (sscanf(str,"%ld", &n)!=EOF && n>=0)
			fibonacci(n);
	}
	
	exit(0);
}


long int fibonacci(long int n)
{
	struct timeval b,e;
	float time;
	long int n_2=0, n_1=1, aux;
	char str[100];

	gettimeofday(&b,NULL);

	if (n >= N)  // Element nth has not yet been calculated
	{
      /* TO DO */
	   /* Reserve memory for N elements in the vector fib */

		if (N>=2)
		{
			n_1 = atol(fib[N-1]);
			n_2 = atol(fib[N-2]);
		}

		for (; N<=n; N++)
		{
			if (N==0) 
				store(N,0);
			else {
				if (N==1) 
					store(N,1);
				else 
				{
					store(N,n_1+n_2);
					aux=n_2;				
					n_2=n_1;
					n_1=n_1+aux;
				}
			}
		}
	}

	gettimeofday(&e,NULL);	

	time = (e.tv_sec-b.tv_sec) + (e.tv_usec-b.tv_usec)/1000000.0;
	sprintf(str, "%ldth -> %s in %lf seconds.\n", n, fib[n], time);
	write(1,str,strlen(str));
}

void store(long int n, long int res)
{
	/* TO DO */
	/* Reserve memory for nth element, convert to string and write */
}

unsigned numDigits(long int number)
{
   int digits = 0;

	if (number==0) return 1;
   while (number) {
        number /= 10;
        digits++;
   }
   return digits;
}

void freeMemory()
{
	/* TO DO */
	/* Free all reserved memory */
}
