#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define N 1000

int main(int argc, char* argv[])
{
	int x;
	
	if (argc<2) {
		write(2,"Error arguments: show <char> ", strlen("Error arguments: show <char> "));
		exit(1);
	}

	while(1)
		write(1,argv[1],strlen(argv[1]));
	
	exit(0);
}
