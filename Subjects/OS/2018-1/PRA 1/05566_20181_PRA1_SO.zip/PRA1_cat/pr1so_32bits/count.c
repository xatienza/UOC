#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
	int x=0;
	
	while(1)
		x++;
	
	exit(0);
}
