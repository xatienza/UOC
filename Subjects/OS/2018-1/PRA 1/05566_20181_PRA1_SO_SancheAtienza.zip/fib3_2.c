#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define rfib(x) rfib2(x,1,0)

typedef int bool;
#define true 1;
#define false 0;

long int rfib2(long int n, long int val, long int prev);
void fibonacci(int fdin, int fdout);
int read_number(int fd, long int *n, int max);

int main (int argc, char *argv[])
{
	char *defaultStdOut = "result.txt";

	long int n;
	char *filein=NULL, *fileout=NULL;
	int fdin=-1,fdout=-1;
	bool stdinRedirected = false;
    bool stdoutRedirected = false;

	if (argc > 1) {
		filein = argv[1];
		stdinRedirected = true;
	} else {
		stdinRedirected = false;
	}

	if (argc > 2) {
		fileout = argv[2];
        stdoutRedirected = false;
	} else {
		// Assign the file descriptor for stdin.
		fileout = defaultStdOut;
        stdoutRedirected = true;
	}

	if (filein!=NULL && stdinRedirected) {
		fdin = open(filein, O_RDONLY);

		if (fdin<0)
			perror("Error opening filein. ");
	} else {
		fdin = 0;
	}

	if (fileout!=NULL && !stdoutRedirected) {
		fdout = open(fileout, O_WRONLY | O_CREAT | O_TRUNC, 0660);
    } else {
        fdout = 1;
    }


	if (fdout<0)
		perror("Error opening fileout.");
	
	
	if (fdin<0 || fdout<0) {
		perror("Error in arguments: fib3 FileIn FileOut.\n");
		exit(1);
	}
	

	fibonacci(fdin, fdout);

	if ( fdin > 0 ) {
		close(fdin);
	}


	if (fdout>0)
		close(fdout);

	exit(0);
}


void fibonacci(int fdin, int fdout)
{
	long int n, fab;
	char str[30];
	int ret;

	while((ret=read_number(fdin, &n, 30))>=0)
	{
		if (ret>0) 
		{ 
			fab = rfib(n);
			sprintf(str,"%ld\n",fab);
			if (write(fdout, str, strlen(str))<0)  {
				perror("Error writting in output file. ");
				exit(1);
			}
		}
	}
}

long int rfib2(long int n, long int val, long int prev)
{
	if (n==0)
		return prev;

	if (n==1)
		return val;
	
	return rfib2(n-1, val+prev, val);
}


int read_number(int fd, long int *n, int max)
{
	char number_str[30];
	int ret,ret2, x=0;
	
	strcpy(number_str,"");
	while( (ret=read(fd,&number_str[x++],1))>0 && number_str[x-1]!=' ' && number_str[x-1]!='\n' && x<max);
	number_str[x]='\0';
	
	if (ret<0)
		return(ret);
	else 
	{
		ret2=sscanf(number_str,"%ld", n);
		if (ret2<=0 && ret<=0)
			return(-1);
		else
			return(ret2);
	}
}

