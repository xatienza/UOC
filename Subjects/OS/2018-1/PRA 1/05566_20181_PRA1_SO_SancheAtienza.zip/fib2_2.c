#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define rfib(x) rfib2(x,1,0)


/* 
Xavier Sánchez => Define a constant to set the minimum value o parameters
*/
#define MIN_REQUIRED 2


/* 
Xavier Sánchez => Change the basic type of parameter val and prev. Now this parameters
accepts values of range [0, +18,446,744,073,709,551,615] (source wikipedia) 
*/
long int rfib2(int n, unsigned long long val,unsigned long long prev);

int main (int argc, char *argv[])
{
	long int n;
	char str[30];

    /* 
    Xavier Sánchez => Check the number of parameters (Minimum 1)
    */
   	if (argc < MIN_REQUIRED) {
	  printf("You have to pass at least one number");
	  exit(-1);
	}

	n = atol(argv[1]);

    /* 
    Xavier Sánchez => Check the the value of the first parameter (Cannot be minius than 0)
    */
    if (n < 0)  {
	  printf("Argument's value must be greater or equal to zero");
	  exit(-1);
	}

	sprintf(str,"Fibonacci %ld-th number -> %ld.\n",n, rfib(n));
	write(1,str,strlen(str));
	
	exit(0);
}

/* 
Xavier Sánchez => Change the basic type of parameter val and prev. Now this parameters
                              7 540 113 804 746 346 429
accepts values of range [0, +18,446,744,073,709,551,615] (source wikipedia) 
*/
long int rfib2(int n, unsigned long long val,unsigned long long prev)
{
	if (n==0)
		return prev;

	if (n==1)
		return val;
	
	return rfib2(n-1, val+prev, val);
}
